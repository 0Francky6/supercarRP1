<?php
include ("Bdconnect.php");

$ID = $_GET["idcontact"]; 

      // Requête SQL corrigée
      $supprimer = "DELETE FROM contacts 
      WHERE idcontact = $ID";

      // Exécution de la requête
      mysqli_query($bdd, $supprimer);
      mysqli_close($bdd);

   header("Location: contact.php");
?>
